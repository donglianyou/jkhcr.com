<?php
/*
 * ============================================================================
 * 版权所有 114mps研发团队，保留所有权利。
 * 网站地址: http://my.roebx.com；
 * 博客教程：http://blog.csdn.net/qq_35921430；
 * ----------------------------------------------------------------------------
 * 这是一个自由软件！您可以对程序代码进行修改和使用。
 * ============================================================================
 * 程序交流QQ：3479015851
 * QQ群 ：625621054  [入群提供技术支持,升级新功能]
`*/
function get_special_subject( $arr = "" )
{
				require_once( QQ3479015851_DATA."/info_special.inc.php" );
				foreach ( $specialarray as $key => $val )
				{
								$qq3479015851 .= "<label for=\"".$key."\">";
								$qq3479015851 .= "<input class=\"checkbox\" ";
								$qq3479015851 .= is_array( $arr ) ? in_array( $key, $arr ) ? "checked " : "" : "";
								$qq3479015851 .= "type=\"checkbox\" name=\"parameter[special][]\" value=\"".$key."\" id=\"".$key."\">".$val;
								$qq3479015851 .= "</label>";
								$qq3479015851 .= in_array( $key, array( 3, 6 ) ) ? "<hr style=\"height:1px; border:1px #C5D8E8 solid;\">" : "";
				}
				return $qq3479015851;
}

function get_special_news( $arr = "" )
{
				$specialarray = array( );
				$specialarray[1] = "推荐新闻";
				$specialarray[2] = "图片新闻";
				foreach ( $specialarray as $key => $val )
				{
								$qq3479015851 .= "<label for=\"".$key."\">";
								$qq3479015851 .= "<input class=\"checkbox\" ";
								$qq3479015851 .= is_array( $arr ) ? in_array( $key, $arr ) ? "checked " : "" : "";
								$qq3479015851 .= "type=\"checkbox\" name=\"parameter[special][]\" value=\"".$key."\" id=\"".$key."\">".$val;
								$qq3479015851 .= "</label>";
				}
				return $qq3479015851;
}

function get_special_store( $arr = "" )
{
				$specialarray = array( );
				$specialarray[1] = "列表推荐商家";
				$specialarray[2] = "首页推荐商家";
				$specialarray[3] = "执照认证商家";
				foreach ( $specialarray as $key => $val )
				{
								$qq3479015851 .= "<label for=\"".$key."\">";
								$qq3479015851 .= "<input class=\"checkbox\" ";
								$qq3479015851 .= is_array( $arr ) ? in_array( $key, $arr ) ? "checked " : "" : "";
								$qq3479015851 .= "type=\"checkbox\" name=\"parameter[special][]\" value=\"".$key."\" id=\"".$key."\">".$val;
								$qq3479015851 .= "</label>";
				}
				return $qq3479015851;
}

function get_special_goods( $arr = "" )
{
				$specialarray = array( );
				$specialarray[1] = "推荐商品";
				$specialarray[2] = "热卖商品";
				$specialarray[3] = "促销商品";
				$qq3479015851 = "<select name=\"parameter[special][]\" class=\"select\">";
				$qq3479015851 .= "<option value=\"\">不限类型</option>";
				foreach ( $specialarray as $key => $val )
				{
								$qq3479015851 .= "<option value=\"".$key."\"";
								$qq3479015851 .= is_array( $arr ) ? in_array( $key, $arr ) ? "checked " : "" : "";
								$qq3479015851 .= "  >".$val;
								$qq3479015851 .= "</option>";
				}
				$qq3479015851 .= "</select>";
				return $qq3479015851;
}

define( "CURSCRIPT", "jswizard" );
require_once( dirname( __FILE__ )."/global.php" );
require_once( QQ3479015851_INC."/db.class.php" );
require_once( dirname( __FILE__ )."/include/customtype.inc.php" );
if ( $admin_cityid )
{
				write_msg( "您没有权限访问该页！" );
}
$part = $part ? trim( $part ) : "default";
$action = $action ? trim( $action ) : "";
if ( !defined( "IN_ADMIN" ) || !defined( "QQ3479015851" ) )
{
				exit( "Access Denied" );
}
if ( !submit_check( CURSCRIPT."_submit" ) )
{
				chk_admin_purview( "purview_数据调用" );
				switch ( $part )
				{
				case "settings" :
								$here = "数据调用 - 基本设置";
								$query = $db->query( "SELECT * FROM `".$db_qq3479015851."config` WHERE type = 'jswizard'" );
								while ( $row = $db->fetchRow( $query ) )
								{
												$settings[$row['description']] = $row['value'];
								}
								include( qq3479015851_tpl( CURSCRIPT."_".$part ) );
								break;
				case "add" :
								$here = "增加".$customtypearr[$customtype]."调用项目";
								include( qq3479015851_tpl( $customtype == "info" ? CURSCRIPT : CURSCRIPT."_".$customtype ) );
								break;
				case "detail" :
								if ( empty( $id ) )
								{
												write_msg( "很抱歉，没有该数据调用项目！" );
								}
								$paramete = $db->getRow( "SELECT * FROM `".$db_qq3479015851."jswizard` WHERE id = '".$id."'" );
								$flag = $paramete['flag'];
								$parameter = array( );
								$parameter = $charset == "utf-8" ? utf8_unserialize( $paramete['parameter'] ) : unserialize( $paramete['parameter'] );
								$parameter['jstemplate'] = stripslashes( $parameter['jstemplate'] );
								$customtype = $paramete['customtype'];
								$here = $customtypearr[$customtype]."调用项目管理";
								$customtype = !$customtype ? "info" : $customtype;
								include( qq3479015851_tpl( $customtype == "info" ? CURSCRIPT : CURSCRIPT."_".$customtype ) );
								break;
				case "default" :
								$randam = $db->getOne( "SELECT MAX(id) FROM ".$db_qq3479015851."jswizard" ) + 1;
								$randam .= random( 3 );
								$here = "数据调用";
								$rows_num = qq3479015851_count( "jswizard" );
								$param = setparam( array( "part" ) );
								$pagi = page1( "SELECT * FROM `".$db_qq3479015851."jswizard` ORDER BY id DESC" );
								foreach ( $pagi as $key => $val )
								{
												$jswizard[$val['id']]['id'] = $val['id'];
												$jswizard[$val['id']]['customtype'] = $val['customtype'];
												$jswizard[$val['id']]['flag'] = $val['flag'];
												$jswizard[$val['id']]['edittime'] = $val['edittime'];
												$jswizard[$val['id']]['parameter'] = $charset == "utf-8" ? utf8_unserialize( $val['parameter'] ) : unserialize( $val['parameter'] );
												$jswizard[$val['id']]['jscharset'] = $jswizard[$val['id']]['parameter']['jscharset'];
								}
								include( qq3479015851_tpl( CURSCRIPT."_".$part ) );
				}
	}			
				else
				{
								if ( is_array( $delids ) )
								{
												$db->query( "DELETE FROM `".$db_qq3479015851."jswizard` WHERE ".create_in( $delids, "id" ) );
												$string = "删除数据调用项目";
												write_jswizard_cache( );
												write_msg( "成功".$string."", $return_url ? $return_url : "?part=default", "write_record" );
												exit( );
								}
								if ( is_array( $settingsnew ) )
								{
												qq3479015851_delete( "config", "WHERE type = 'jswizard'" );
												foreach ( $settingsnew as $key => $val )
												{
																$db->query( "INSERT INTO `".$db_qq3479015851."config` (`description`,`value`,`type`)VALUES('".$key."','".$val."','jswizard')" );
												}
												update_jswizard_settings( );
												write_msg( "成功更新信息调用基本设置！", $return_url, "write_record" );
								}
								if ( empty( $id ) )
								{
												if ( empty( $flag ) || !is_array( $parameter ) )
												{
																write_msg( "唯一标识不能为空！相关配置不能为空！" );
												}
												if ( empty( $parameter['jstemplate'] ) )
												{
																write_msg( "数据调用模板内容不能为空！" );
												}
												if ( 0 < $db->getOne( "SELECT count(id) FROM `".$db_qq3479015851."jswizard` WHERE flag = '".$flag."'" ) )
												{
																write_msg( "该标识已经存在，请更换一个唯一标识！" );
												}
												$parameter = addslashes( serialize( $parameter ) );
												$db->query( "INSERT INTO `".$db_qq3479015851."jswizard` (`flag`,`customtype`,`parameter`,`edittime`)VALUES('".$flag."','".$customtype."','".$parameter."','".$timestamp."')" );
												$string = "添加数据调用";
												$return_url = "?part=detail&id=".$db->insert_id( );
								}
								else
								{
												if ( empty( $flag ) || !is_array( $parameter ) )
												{
																write_msg( "唯一标识不能为空！相关配置不能为空！" );
												}
												$parameter = addslashes( serialize( $parameter ) );
												$db->query( "UPDATE `".$db_qq3479015851."jswizard` SET flag='".$flag."',parameter='".$parameter."',edittime = '".$timestamp."' WHERE id = '".$id."'" );
												$string = "修改数据调用";
												$return_url = "?part=detail&id=".$id;
												clear_cache_files( "javascript_".$flag );
								}
								write_jswizard_cache( );
								write_msg( "成功".$string."", $return_url ? $return_url : "?part=default", "write_record" );
				}

if ( is_object( $db ) )
{
				$db->Close( );
}
$qq3479015851_global = $db = $db_qq3479015851 = $part = NULL;
?>
