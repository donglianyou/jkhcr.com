<?php
$cityid=279;
require dirname(__FILE__).'/../../'.basename(__FILE__);
?>