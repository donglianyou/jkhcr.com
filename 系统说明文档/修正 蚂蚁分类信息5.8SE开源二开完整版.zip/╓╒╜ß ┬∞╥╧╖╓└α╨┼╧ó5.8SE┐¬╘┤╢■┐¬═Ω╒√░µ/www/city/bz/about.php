<?php
$cityid=258;
require dirname(__FILE__).'/../../'.basename(__FILE__);
?>