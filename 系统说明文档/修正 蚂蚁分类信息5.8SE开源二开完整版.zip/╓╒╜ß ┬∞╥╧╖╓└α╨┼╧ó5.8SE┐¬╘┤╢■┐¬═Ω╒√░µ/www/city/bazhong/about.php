<?php
$cityid=294;
require dirname(__FILE__).'/../../'.basename(__FILE__);
?>