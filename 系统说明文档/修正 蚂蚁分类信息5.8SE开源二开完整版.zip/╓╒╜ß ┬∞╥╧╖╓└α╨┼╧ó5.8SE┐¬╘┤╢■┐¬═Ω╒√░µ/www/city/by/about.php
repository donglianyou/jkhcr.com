<?php
$cityid=67;
require dirname(__FILE__).'/../../'.basename(__FILE__);
?>