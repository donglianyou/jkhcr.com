<?php
$cityid=318;
require dirname(__FILE__).'/../../'.basename(__FILE__);
?>