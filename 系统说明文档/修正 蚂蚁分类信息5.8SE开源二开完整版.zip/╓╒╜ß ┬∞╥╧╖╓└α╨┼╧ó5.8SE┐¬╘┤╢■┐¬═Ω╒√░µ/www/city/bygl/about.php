<?php
$cityid=316;
require dirname(__FILE__).'/../../'.basename(__FILE__);
?>