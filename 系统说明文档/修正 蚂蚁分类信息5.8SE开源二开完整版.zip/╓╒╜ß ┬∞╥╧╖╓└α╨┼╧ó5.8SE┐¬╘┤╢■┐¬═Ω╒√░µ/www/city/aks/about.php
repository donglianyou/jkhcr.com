<?php
$cityid=314;
require dirname(__FILE__).'/../../'.basename(__FILE__);
?>