<?php
$cityid=209;
require dirname(__FILE__).'/../../'.basename(__FILE__);
?>