<?php
$cityid=177;
require dirname(__FILE__).'/../../'.basename(__FILE__);
?>